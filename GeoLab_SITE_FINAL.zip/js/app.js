
const menu=document.querySelector('.menu'),links=document.querySelector('.links');
if(menu) menu.addEventListener('click',()=>links.classList.toggle('mobile'));
const search=document.querySelector('#courseSearch');
if(search) search.addEventListener('input',()=>{const q=search.value.toLowerCase();document.querySelectorAll('.course-card').forEach(c=>c.classList.toggle('hidden',q&&!c.textContent.toLowerCase().includes(q)))});
